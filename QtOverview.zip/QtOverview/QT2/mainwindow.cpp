#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QLabel>
#include <QTextBrowser>
#include <QTextDocument>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->label->setText("Hello");
    ui->label->setFrameStyle(10);
    QString html;
    html = "<html><head>"
           "<link rel='stylesheet' type='text/css' href='format.css'>"
           "</head><body>"
           "Your HTML code with tags, which have classes or ids. For example "
           "<span class='red'>this text is colored red</span>.<br/>"
           "And you can also display images: <img src='myImage.png'><br/>"
           "Combine css and images: <span id='bgimage'>foo bar</span>"
           "</body></html>";
    //ui->textBrowser->setSource(QUrl("https://www.google.com.vn/"));
    QTextDocument *doc = new QTextDocument;
    doc->setHtml(html);
    ui->textBrowser->setDocument(doc);
}

MainWindow::~MainWindow()
{
    delete ui;
}
