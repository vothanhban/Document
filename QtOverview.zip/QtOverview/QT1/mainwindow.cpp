#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QLayout>
#include <QPlainTextEdit>
#include <QComboBox>
#include <QFontComboBox>
#include <QSpinBox>
#include <QDoubleSpinBox>
#include <QTimeEdit>
#include <QDateEdit>
#include <QDateTimeEdit>
#include <QScrollBar>
#include <QSlider>
#include <QImage>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
   // txtEdit = new QTextEdit("txtEdit");
   // txtEdit->show();
    ui->setupUi(this);
    ui->spinBox->setMaximum(20);
    ui->doubleSpinBox->setMaximum(20.00);
    ui->spinBox->setSingleStep(2);
    ui->doubleSpinBox->setSingleStep(0.01);
    QDate date = ui->dateTimeEdit->minimumDate();
    QDate date2 = ui->dateTimeEdit->maximumDate();
    QString format = ui->dateTimeEdit->displayFormat();
    ui->textEdit1->setText(format);
    //ui->dateEdit->setDate(3545545);
    ui->dateTimeEdit->setTime(ui->timeEdit->maximumTime());
    ui->horizontalScrollBar->setMaximum(1000);
    int max = ui->verticalScrollBar->maximum();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_comboBox_currentIndexChanged(int index)
{
    QString string;
    QStringList items;
    items << "78" << "10";
    ui->comboBox->setEditable(true);
    //ui->spinBox->setMaximum(1000);
    switch (index)
    {
    case 0:
       // ui->textEdit1->setText("0");
        ui->comboBox->addItems(items);
        string = ui->textEdit1->toPlainText();
       // ui->textEdit2->setDisabled(true);
        //ui->textEdit2->setText(string);
        ui->textEdit2->setText(ui->comboBox->currentText());

    break;
    case 1:
        ui->textEdit1->setText("1");
        ui->textEdit2->setDisabled(true);
    break;
    default:
        ui->textEdit1->setText("10");
        ui->textEdit2->setDisabled(false);
        ui->lineEdit->setText("this is line edit");

    }
}

void MainWindow::on_fontComboBox_currentIndexChanged(int index)
{
    QFont newFont = ui->fontComboBox->currentFont();
    //ui->lineEdit->setFont(newFont);
    QApplication::setFont(newFont);
}

void MainWindow::on_timeEdit_timeChanged(const QTime &time)
{
    //ui->timeEdit->setTime(time);
}

void MainWindow::on_pushButton_clicked()
{
    QTime time = ui->timeEdit->time();
    ui->timeEdit2->setTime(time);
    ui->textEdit1->setText(time.toString("h:mm:ss"));
}

void MainWindow::on_horizontalScrollBar_sliderMoved(int position)
{
    ui->textEdit1->setText(QString::number(position));
}
