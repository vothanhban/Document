#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QLCDNumber>
#include <QProgressBar>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->progressBar->setValue(35);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_horizontalSlider_sliderMoved(int position)
{
    ui->lcdNumber->display(position);
    ui->lcdNumber2->display(ui->horizontalSlider->maximum() - position);
    ui->progressBar->setValue(position);
}
